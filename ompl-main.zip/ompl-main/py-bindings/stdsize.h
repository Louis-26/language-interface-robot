namespace std
{
    using size_t = unsigned long;
#ifdef __APPLE__
    using uint_fast32_t = unsigned int;
#endif
}